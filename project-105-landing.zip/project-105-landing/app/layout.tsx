import type { Metadata } from 'next'
import { Assistant } from 'next/font/google'
import './globals.css'

const assistant = Assistant({ subsets: ['hebrew'] })

export const metadata: Metadata = {
  title: 'פרויקט 105',
  description: 'פרויקט מיינקראפט ורובלוקס על ידי קבוצת פרלמנטום',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="he" dir="rtl">
      <body className={assistant.className}>{children}</body>
    </html>
  )
}

