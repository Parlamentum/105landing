import Hero from './components/Hero'
import PhotoGallery from './components/PhotoGallery'
import BrandCredits from './components/BrandCredits'
import HowToJoin from './components/HowToJoin'
import ContactUs from './components/ContactUs'
import Footer from './components/Footer'

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <PhotoGallery />
      <BrandCredits />
      <HowToJoin />
      <ContactUs />
      <Footer />
    </main>
  )
}

