import Image from 'next/image'
import Link from 'next/link'

export default function BrandCredits() {
  const partners = [
    { 
      name: 'ליאו ברנט', 
      image: '/placeholder.svg?height=200&width=200',
      url: 'https://www.leoburnett.com/'
    },
    { 
      name: 'Tech.co.il', 
      image: '/placeholder.svg?height=200&width=200',
      url: 'https://tech.co.il'
    },
    { 
      name: 'קבוצת הפרלמנטום', 
      image: '/placeholder.svg?height=200&width=200',
      url: 'https://parlamentum.group'
    },
  ]

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">שותפים</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {partners.map((partner, index) => (
            <Link 
              href={partner.url}
              key={index}
              target="_blank"
              rel="noopener noreferrer"
              className="text-center group"
            >
              <div className="relative w-48 h-48 mx-auto mb-4 overflow-hidden rounded-lg">
                <Image 
                  src={partner.image} 
                  alt={partner.name} 
                  layout="fill" 
                  objectFit="cover"
                  className="transition-all duration-300 filter grayscale hover:grayscale-0 group-hover:scale-105"
                />
              </div>
              <h3 className="text-xl font-semibold group-hover:text-blue-600 transition-colors">
                {partner.name}
              </h3>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

