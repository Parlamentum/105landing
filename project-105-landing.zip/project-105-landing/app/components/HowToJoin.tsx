'use client'

import { useState } from 'react'
import { Copy, ExternalLink } from 'lucide-react'
import Link from 'next/link'

export default function HowToJoin() {
  const [copied, setCopied] = useState(false)
  const minecraftIP = '105hub.co.il'
  const robloxGameUrl = 'https://www.roblox.com/games/86837427569575'

  const copyToClipboard = () => {
    navigator.clipboard.writeText(minecraftIP)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">איך להצטרף</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="flex flex-col">
            <h3 className="text-2xl font-bold mb-4">רובלוקס</h3>
            <div className="mb-4">
              <p className="mb-4">כדי להצטרף לחוויה ברובלוקס:</p>
              <ol className="list-decimal mr-5 space-y-2">
                <li>פתחו את רובלוקס</li>
                <li>חפשו "Project 105" בחוויות</li>
                <li>לחצו על החוויה כדי להצטרף</li>
                <li>תהנו ותשמרו על עצמכם!</li>
              </ol>
            </div>
            <div className="mt-auto">
              <Link 
                href={robloxGameUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded inline-flex items-center"
              >
                <ExternalLink className="w-4 h-4 ml-2" />
                <span>למשחק</span>
              </Link>
            </div>
          </div>
          <div className="flex flex-col">
            <h3 className="text-2xl font-bold mb-4">מיינקראפט</h3>
            <div className="mb-4">
              <p className="mb-4">כדי להצטרף לשרת המיינקראפט:</p>
              <ol className="list-decimal mr-5 space-y-2">
                <li>פתחו את מיינקראפט Java Edition (גרסה 1.21.1-1.21.3)</li>
                <li>עברו למצב ריבוי משתתפים</li>
                <li>לחצו על "הוסף שרת"</li>
                <li>הזינו שם לשרת (למשל, "פרויקט 105")</li>
                <li>הזינו את כתובת השרת: {minecraftIP}</li>
                <li>לחצו על "סיום" ואז הצטרפו לשרת</li>
              </ol>
            </div>
            <div className="mt-auto">
              <button
                onClick={copyToClipboard}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded inline-flex items-center"
              >
                <Copy className="w-4 h-4 ml-2" />
                <span>{copied ? 'הועתק!' : 'העתק IP'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

