import Link from 'next/link'
import { DiscIcon as Discord, Facebook, Twitter } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link href="https://parlamentum.group" className="text-xl font-bold">
              קבוצת פרלמנטום
            </Link>
          </div>
          <div className="flex space-x-4 space-x-reverse">
            <Link href="https://discord.gg/parlamentum" className="hover:text-gray-300">
              <Discord className="w-6 h-6" />
              <span className="sr-only">דיסקורד</span>
            </Link>
            <Link href="https://facebook.com/parlamentum" className="hover:text-gray-300">
              <Facebook className="w-6 h-6" />
              <span className="sr-only">פייסבוק</span>
            </Link>
            <Link href="https://twitter.com/parlamentum" className="hover:text-gray-300">
              <Twitter className="w-6 h-6" />
              <span className="sr-only">טוויטר</span>
            </Link>
          </div>
        </div>
        <div className="mt-4 text-center text-sm">
          © {new Date().getFullYear()} קבוצת פרלמנטום. כל הזכויות שמורות.
        </div>
      </div>
    </footer>
  )
}

