import Image from 'next/image'
import Link from 'next/link'

export default function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-gray-900">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-6xl font-bold text-gray-500">מציין מקום לוידאו</div>
      </div>
      <div className="z-10 text-center text-white">
        <h1 className="text-5xl font-bold mb-4">פרויקט 105</h1>
        <p className="text-xl mb-8">פרויקט מיינקראפט ורובלוקס על ידי קבוצת פרלמנטום</p>
        <p className="text-2xl mb-8">מוקד 105 המטה הלאומי להגנת ילדים ברשת</p>
        <div className="flex justify-center space-x-4 space-x-reverse">
          <Link href="#minecraft" className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <Image src="/minecraft-logo.png" alt="לוגו מיינקראפט" width={24} height={24} className="ml-2" />
            <span>מיינקראפט</span>
          </Link>
          <Link href="#roblox" className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <Image src="/roblox-logo.png" alt="לוגו רובלוקס" width={24} height={24} className="ml-2" />
            <span>רובלוקס</span>
          </Link>
        </div>
      </div>
    </section>
  )
}

