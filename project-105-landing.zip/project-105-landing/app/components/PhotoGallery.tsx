import Image from 'next/image'

export default function PhotoGallery() {
  const photos = [
    { width: 800, height: 600 },
    { width: 800, height: 600 },
    { width: 800, height: 600 },
    { width: 800, height: 600 },
  ]

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">גלריית הפרויקט</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {photos.map((photo, index) => (
            <div key={index} className="aspect-w-16 aspect-h-9 relative">
              <Image 
                src={`/placeholder.svg?height=${photo.height}&width=${photo.width}`}
                alt={`תמונה ${index + 1} של פרויקט 105`} 
                layout="fill" 
                objectFit="cover" 
                className="rounded-lg"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

